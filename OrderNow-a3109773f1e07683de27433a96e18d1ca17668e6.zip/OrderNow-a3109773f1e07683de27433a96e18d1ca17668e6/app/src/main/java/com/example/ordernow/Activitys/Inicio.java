package com.example.ordernow.Activitys;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.ordernow.R;

public class Inicio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
    }
}
